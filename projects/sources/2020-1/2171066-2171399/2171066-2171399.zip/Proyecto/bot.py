import nltk   #libreria para el lenguaje natural
from nltk.stem.lancaster import LancasterStemmer
stemmer=LancasterStemmer()
import numpy  #crear arreglos
import tflearn  
import tensorflow  #red neuronal
import json    #creacion de archivo para la lectura
import random
import discord

#nltk.download('punkt')      #descargar libreria 
llave="NzUxMTAyOTk0NjQwMDExMzQ1.X1ENLA.q3kolBUGQBiwE0a8vlmUGZ7r6zY"
with open ("contenido.json",encoding='utf-8') as archivo:        #abrir el .json donde tenemos las palabras claves y sus tags
	dato= json.load(archivo)                   #almacenar los datos del json
 
palabras=[] # contendra las palabras
tags=[]
auxX=[]#contendra las palabras separadas 
auxY=[]#contendra los tags

for contenido in dato["contenido"]:     #recorre todo el json con modulo contenido
	for patrones in contenido["patrones"]: #recoje los patrones que colocamos como palabras clave
		auxPalabra=nltk.word_tokenize(patrones) #separa por palabras las frases junto con signos
		palabras.extend(auxPalabra) #le pasamos las palabras
		auxX.append(auxPalabra)  #guardamos las palabras
		auxY.append(contenido["tag"]) #guardamos los tags

		if contenido["tag"] not in tags:  # no los deja repetir
			tags.append(contenido["tag"])  #guarda los tags sin repetir
palabras=[stemmer.stem(w.lower())for w in palabras if w!= "?"]#omite el signo de pregunta y pasa a minuscla
palabras=sorted(list(set(palabras))) #ordenar las palabras y devuelve la lista
tags=sorted(tags)#ordena los tags y devuelve la lista

entrenamiento=[]  
salida=[]
salidaVacia=[0 for _ in range(len(tags))]

for x, documento in enumerate(auxX):   # x guarda los indices y documento los datos
	frase=[]
	auxPalabra=[stemmer.stem(w.lower()) for w in documento] 
	for w in palabras:
		if w in auxPalabra: #si encuentra un elemento que este en el documento lo avisa
			frase.append(1)
		else:
			frase.append(0)

	filaSalida=salidaVacia[:] 
	filaSalida[tags.index(auxY[x])]=1   # con los tag tendremos el indice de los tags
	entrenamiento.append(frase)  #le pasamos si encuentra  donde encuentra palabras claves
	salida.append(filaSalida)


entrenamiento = numpy.array(entrenamiento)#convertimos las listas a arreglos de numpy
salida = numpy.array(salida) # tenemos los tag

tensorflow.reset_default_graph() #borrar cache y por defecto de la red neuronal

red=tflearn.input_data(shape=[None,len(entrenamiento[0])])  #creamos la red con longitud de una fila del entrenamiento
red = tflearn.fully_connected(red,10) #relacionamos todas las neuronas con 10 neuronas
red = tflearn.fully_connected(red, 10) # creamos otra fila de neuronas
red = tflearn.fully_connected(red,len(salida[0]),activation="softmax") #es la fila de salidas
red = tflearn.regression(red)  # obtenemos una probabilidad de clasificacion por medio de regresion 

modelo = tflearn.DNN(red)# creMOS UN MODELO
modelo.fit(entrenamiento,salida,n_epoch=1000,batch_size=10,show_metric=True) #entrenamos n_epoch veces, batch depende de el num de palabras clav 
modelo.save("modelo.tflearn")

def mainbot(): #funcion que tome la entrada que se digite y el chat conteste
	cliente=discord.Client()
	global llave
	while True:
		@cliente.event
		async def on_message(mensaje):
			
			if mensaje.author == cliente.user:
				return
			#entrada= input(">>>>:   ") # entrada del usuario
			frase= [0 for _ in range(len(palabras))] #llenamos una frase llena de 0
			entradaProcesada = nltk.word_tokenize(mensaje.content) # procesamos la entrada separar por palabras
			entradaProcesada= [stemmer.stem(palabra.lower()) for palabra in entradaProcesada]# que el bot lo pueda entender
			for palabraIndividual in entradaProcesada:# mirar palabra por palabra
				for i,palabra in enumerate(palabras):  # la i guardara la posicion de la palabra y palabra la palabra "clave"
					if palabra == palabraIndividual:
						frase[i]=1 # avisa que se encontro una palabra clave y la guarda con el indice
			resultado = modelo.predict([numpy.array(frase)]) # predice a que tag pertenece 
			resuldosIndices= numpy.argmax(resultado)
			tag= tags[resuldosIndices]

			for tagaux in  dato["contenido"]:
				if tagaux["tag"]==tag:
					respuesta=tagaux["respuestas"]
			print(resultado)
			await mensaje.channel.send(random.choice(respuesta))
		cliente.run(llave)
mainbot()

